import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'login',
    loadComponent: () => import('./login/login.page').then(m => m.LoginPage),
  },
  {
    path: 'professor-profile',
    loadComponent: () => import('./professor-profile/professor-profile.page').then(m => m.ProfessorProfilePage),
  },
  {
    path: 'student-validation',
    loadComponent: () => import('./student-validation/student-validation.page').then(m => m.StudentValidationPage),
  },
  {
    path: 'qr-scanner',
    loadComponent: () => import('./qr-scanner/qr-scanner.page').then(m => m.QrScannerPage),
  },
  {
    path: 'user-profile',
    loadComponent: () => import('./user-profile/user-profile.page').then(m => m.UserProfilePage),
  },
  {
    path: '**',
    loadChildren: () => import('./error404/error404.module').then( m => m.Error404PageModule)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
