import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConsumoAPIService } from '../services/consumo-api.service';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { QRCodeComponent } from 'angularx-qrcode';

@Component({
  selector: 'app-qr-scanner',
  templateUrl: './qr-scanner.page.html',
  styleUrls: ['./qr-scanner.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule, QRCodeComponent], // Módulos necesarios
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class QrScannerPage implements OnInit {
  cursoSeleccionado: any = null;
  alumnos: any[] = [];
  codigoQR: string = '';

  constructor(private router: Router, private apiService: ConsumoAPIService) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state?.['curso']) {
      this.cursoSeleccionado = navigation.extras.state['curso'];
    } else {
      console.error('No se ha recibido un curso válido.');
      this.router.navigate(['/professor-profile']);
    }
  }

  ngOnInit() {
    if (this.cursoSeleccionado) {
      this.generarQR();
      this.cargarAlumnos();
    }
  }

  generarQR() {
    if (this.cursoSeleccionado?.codigo) {
      const cursoCodigo = this.cursoSeleccionado.codigo;
      const profesorId = 'Profesor1';
      this.codigoQR = `${cursoCodigo}-${profesorId}`;
    } else {
      console.error('Datos del curso incompletos para generar el QR.');
    }
  }

  cargarAlumnos() {
    this.apiService.getAlumnosCurso(1, this.cursoSeleccionado.id).subscribe(
      (data: any[]) => {
        this.alumnos = data;
      },
      (error) => {
        console.error('Error al cargar los alumnos:', error);
      }
    );
  }

  volver() {
    this.router.navigate(['/professor-profile']);
  }
}
