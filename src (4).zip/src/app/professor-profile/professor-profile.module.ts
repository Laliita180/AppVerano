import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ProfessorProfilePageRoutingModule } from './professor-profile-routing.module';

import { ProfessorProfilePage } from './professor-profile.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ProfessorProfilePageRoutingModule
  ],
  declarations: [ProfessorProfilePage],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ProfessorProfilePageModule {}
