import { Component, CUSTOM_ELEMENTS_SCHEMA, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConsumoAPIService } from '../services/consumo-api.service';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-professor-profile',
  templateUrl: './professor-profile.page.html',
  styleUrls: ['./professor-profile.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule], // Asegúrate de importar estos módulos
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Esto permitirá usar componentes de Ionic
})
export class ProfessorProfilePage implements OnInit {
  profesorNombre: string = 'Profesor Juan Pérez';
  cursos: any[] = [];
  currentDate: string;

  constructor(private router: Router, private apiService: ConsumoAPIService) {
    const hoy = new Date();
    this.currentDate = hoy.toLocaleDateString('es-ES', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  }

  ngOnInit() {
    this.cargarCursos();
  }

  cargarCursos() {
    this.apiService.getCursosProfesor(1).subscribe(
      (data: any[]) => {
        this.cursos = data;
      },
      (error) => {
        console.error('Error al cargar los cursos:', error);
      }
    );
  }

  irAGenerarQR(curso: any) {
    if (curso) {
      this.router.navigate(['/qr-scanner'], { state: { curso } });
    } else {
      console.error('Curso inválido para generar QR.');
    }
  }
}
