import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-error404',
  templateUrl: './error404.page.html',
  styleUrls: ['./error404.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class Error404Page {
  constructor(private router: Router) {}

  goToLogin() {
    const navigationExtras: NavigationExtras = {
      queryParams: {
        redirect: 'error404',
      },
    };
    this.router.navigate(['/login'], navigationExtras);
  }
}
