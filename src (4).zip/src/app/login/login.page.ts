import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { IonicModule, ToastController } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
})
export class LoginPage {
  username: string = ''; // Nombre de usuario ingresado
  password: string = ''; // Contraseña ingresada

  // Credenciales simuladas
  credentials = {
    student: { username: 'student', password: '1234' },
    professor: { username: 'professor', password: '1234' },
  };

  constructor(private router: Router, private toastController: ToastController) {}

  /**
   * Valida las credenciales ingresadas y redirige según el rol.
   */
  async login() {
    if (
      this.username === this.credentials.student.username &&
      this.password === this.credentials.student.password
    ) {
      await this.showToast('Bienvenid@ María López', 'success');
      this.router.navigate(['/student-validation']); // Redirige a la página de estudiantes
    } else if (
      this.username === this.credentials.professor.username &&
      this.password === this.credentials.professor.password
    ) {
      await this.showToast('Bienvenid@ José Pérez  ', 'success');
      this.router.navigate(['/professor-profile']); // Redirige a la página de profesores
    } else {
      await this.showToast('Credenciales inválidas. Intente nuevamente.', 'danger');
    }
  }

  /**
   * Muestra un mensaje tipo toast.
   * @param message - Mensaje a mostrar.
   * @param color - Color del toast (success, danger, etc.).
   */
  private async showToast(message: string, color: string) {
    const toast = await this.toastController.create({
      message,
      color,
      duration: 2000,
    });
    toast.present();
  }
}
