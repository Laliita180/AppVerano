import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ConsumoAPIService {
  private cursos = [
    { id: 1, nombre: 'Matemáticas', codigo: 'MAT101', seccion: 'A1' },
    { id: 2, nombre: 'Física', codigo: 'PHY201', seccion: 'B1' },
    { id: 3, nombre: 'Química', codigo: 'CHE301', seccion: 'C1' },
  ];

  private alumnos: { [key: number]: any[] } = {
    1: this.generarAlumnos(30, 'MAT'),
    2: this.generarAlumnos(30, 'PHY'),
    3: this.generarAlumnos(30, 'CHE'),
  };

  // Devuelve la lista de cursos del profesor
  getCursosProfesor(profesorId: number): Observable<any[]> {
    return of(this.cursos);
  }

  // Devuelve la lista de alumnos del curso seleccionado
  getAlumnosCurso(profesorId: number, cursoId: number): Observable<any[]> {
    return of(this.alumnos[cursoId] || []);
  }

  // Genera una lista de alumnos ficticia
  private generarAlumnos(cantidad: number, prefijo: string): any[] {
    const nombres = ['Luis', 'María', 'Carlos', 'Ana', 'Pedro', 'Lucía'];
    return Array.from({ length: cantidad }, (_, i) => ({
      id: i + 1,
      nombre: `${nombres[i % nombres.length]} ${prefijo}${i + 1}`,
      status: 0, // 0 = Ausente
    }));
  }
}
