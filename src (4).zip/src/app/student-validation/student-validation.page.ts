import { Component, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { Router, NavigationExtras } from '@angular/router';
import { BrowserMultiFormatReader } from '@zxing/browser';

@Component({
  selector: 'app-student-validation',
  templateUrl: './student-validation.page.html',
  styleUrls: ['./student-validation.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonicModule],
})
export class StudentValidationPage {
  @ViewChild('video', { static: false }) videoElement!: ElementRef;
  scanner: BrowserMultiFormatReader;
  code: string = ''; // Código ingresado por el estudiante
  mensaje: string = ''; // Mensaje de resultado del escaneo

  // Datos del usuario
  user = {
    rut: '98765432-1',
    nombre: 'María',
    apellidoPaterno: 'López',
    apellidoMaterno: 'Rodríguez',
    correo: 'maria.lopez@example.com',
    usuario: 'student',
    contraseña: '5678',
    telefono: '987123456',
    foto: 'assets/img/default-user.png',
  };

  constructor(private router: Router) {
    this.scanner = new BrowserMultiFormatReader();
  }

  /**
   * Redirige al perfil del usuario usando NavigatorExtras.
   */
  goToUserProfile() {
    const navigationExtras: NavigationExtras = {
      state: {
        user: this.user,
        origin: 'student-validation',
      },
    };
    this.router.navigate(['/user-profile'], navigationExtras);
  }

  /**
   * Valida el código ingresado manualmente.
   */
  validateCode() {
    if (this.code.trim()) {
      console.log(`Código ingresado: ${this.code}`);
      alert(`Código validado: ${this.code}`);
    } else {
      alert('Por favor, ingrese un código.');
    }
  }

  /**
   * Inicia el escaneo de un código QR.
   */
  startScan() {
    this.mensaje = '';
    this.scanner
      .decodeOnceFromVideoDevice(undefined, this.videoElement.nativeElement)
      .then((result) => {
        this.mensaje = `Código escaneado: ${result.getText()}`;
        alert(this.mensaje);
      })
      .catch((err) => {
        this.mensaje = `Error al escanear: ${err}`;
        alert(this.mensaje);
      });
  }
}
