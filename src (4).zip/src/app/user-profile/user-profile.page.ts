import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.page.html',
  styleUrls: ['./user-profile.page.scss'],
  standalone: true,
  imports: [CommonModule, IonicModule],
})
export class UserProfilePage {
  user: any = null; // Datos del usuario
  origin: string = ''; // Página de origen

  constructor(private router: Router) {
    const navigation = this.router.getCurrentNavigation();
    const state = navigation?.extras.state as { user: any; origin: string };

    if (state) {
      this.user = state.user || null; // Datos del usuario
      this.origin = state.origin || ''; // Página de origen
    } else {
      console.warn('Estado de navegación no definido, redirigiendo al login.');
      this.router.navigate(['/']); // Redirige al login si no hay datos
    }
  }

  /**
   * Redirige al login.
   */
  logout() {
    this.router.navigate(['/']); // Redirige al login
  }

  /**
   * Redirige a la página de origen (professor-profile o student-validation).
   */
  goBack() {
    if (this.origin === 'professor-profile') {
      this.router.navigate(['/professor-profile']);
    } else if (this.origin === 'student-validation') {
      this.router.navigate(['/student-validation']);
    } else {
      console.warn('Origen no definido, redirigiendo al login.');
      this.router.navigate(['/']); // Por defecto, redirige al login
    }
  }
}
